const { render } = require('ejs');
const express = require('express')
const app = express ();


app.use('/static', express.static('public'))
app.set('view engine', 'ejs')
app.use(express.urlencoded({extended: true}))

app.get('/', (req, res) => {
    res.render('login');
 });

 app.post('/login', (req, res) => {

   const email = 'teste@gmail.com'
   const senha = '123456'

   if (req.body.email == email && req.body.senha == senha)

   res.render('telainicial')

    console.log(req.body.email);
    console.log(req.body.senha);

 });

 app.get('/compras', (req, res) => {

    res.render('compras')


 });

 app.get('/telainicial', (req, res) => {

   res.render('inicial')
});

 
app.listen(3000, function (){
    console.log('Servidor node no ar!')
})


