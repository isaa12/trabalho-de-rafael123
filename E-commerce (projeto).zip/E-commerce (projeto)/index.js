const express = require('express')
const app = express ();

/*
const server = http.createServer(function (req, res) {
    res.statusCode = 200
    res.setHeader('Content-Type', 'text/html')
    res.end('<h1>Rafinha Tabacão</h1>')
})
*/ 

app.get('/html', (req, res) => {
    res.sendFile(__dirname + '/login.html');
   // res.render('index', {idade: '300'});
 });

 
app.listen(3000, function (){
    console.log('Servidor node no ar!')
})

