const { render } = require('ejs');
const express = require('express')
const app = express ();


app.use('/static', express.static('public'))
app.set('view engine', 'ejs')
app.use(express.urlencoded({extended: true}))

app.get('/', (req, res) => {
    res.render('login');
 });

 app.post('/login', (req, res) => {
   res.redirect('telainicial');
    console.log(req.body.email);
    console.log(req.body.senha);

 });

 app.get('/telainicial', (req, res) => {

   res.render('telainicial')

});

 app.get('/compras', (req, res) => {

   res.render('compras')

});


 
app.listen(3000, function (){
    console.log('Servidor node no ar!')
})

